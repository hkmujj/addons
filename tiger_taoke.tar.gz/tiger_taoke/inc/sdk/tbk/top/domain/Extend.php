<?php

/**
 * 扩展属性
 * @author auto create
 */
class Extend
{
	
	/** 
	 * empty
	 **/
	public $empty;	
}
?>
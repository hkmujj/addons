<?php

/**
 * result
 * @author auto create
 */
class RpcResult
{
	
	/** 
	 * data
	 **/
	public $data;	
}
?>
<?php
global $_GPC,$_W;
		$cfg = $this->module['config'];
		$weid=$_W['uniacid'];
		$px=$_GPC['px'];
		$zt=$_GPC['zt'];//专题
		$type=$_GPC['type'];
		$tm=$_GPC['tm'];
		$price1=$_GPC['price1'];
		$price2=$_GPC['price2'];
		$hd=$_GPC['hd'];
		$page=$_GPC['page'];
		$key=$_GPC['key'];
		$dlyj=$_GPC['dlyj'];
		$pid=$_GPC['pid'];
		$dluid=$_GPC['dluid'];
		
		if($cfg['mmtype']==2){//云商品库
			include IA_ROOT . "/addons/tiger_taoke/inc/sdk/tbk/goodsapi.php"; 
		    $list=getcatlist($type,$px,$tm,$price1,$price2,$hd,$page,$key,$dlyj,$pid,$cfg);
		    if(empty($list['data'])){
				$status=2;
			}else{
				$status=1;//有数据
			}
			exit(json_encode(array('status' => $status, 'content' => $list['data'],'lm'=>2)));
		}else{//自己采集
			//分词搜索
			if(!empty($_GPC['key'])){
	             include IA_ROOT . "/addons/tiger_taoke/inc/sdk/tbk/tb.php"; 
	             $arr=getfc($_GPC['key'],$_W);
	            	foreach($arr as $v){
		                 if (empty($v)) continue;
		                $where.=" and itemtitle like '%{$v}%'";
		            }
	        }

            if(!empty($cfg['gyspsj'])){
               $weid=$cfg['gyspsj'];
             }
	
	        
	        if(empty($_GPC['px'])){
	          $orde='id desc';
	        }elseif($_GPC['px']==1){
	          $orde='itemsale desc';
	        }elseif($_GPC['px']==2){
	          $orde='itemendprice asc';
	        }elseif($_GPC['px']==3){
	          $orde='tkrates desc';
	        }elseif($_GPC['px']==4){
	          $orde='couponmoney desc';
	        }
	        if(!empty($_GPC['tm'])){
	          $where.=" and shoptype='B'";
	        }
	        if(!empty($_GPC['hd'])){//1聚划算  2淘抢购
	           if($_GPC['hd']==1){
	             $where.=" and activity_type='聚划算'";
	           }elseif($_GPC['hd']==2){
	             $where.=" and activity_type='淘抢购'";
	           }elseif($_GPC['hd']==3){//秒杀
	             $where.=" and tj=1";
	           }elseif($_GPC['hd']==4){//叮咚抢
	             $where.=" and tj=2";
	           }elseif($_GPC['hd']==5){//视频单
	             $where.=" and videoid <>0";
	           }
	        }
	        if(!empty($_GPC['price1'])){
	           $where.=" and itemendprice>".$_GPC['price1'];
	        }
	        if(!empty($_GPC['price2']) and !empty($_GPC['price1'])){
	           $where.=" and itemendprice<".$_GPC['price2'];
	        }
	        if(!empty($_GPC['price2']) and empty($_GPC['price1'])){
	           	$where.=" and itemendprice<".$_GPC['price2'];
	        }
	        if(!empty($zt)){
	        	$where.=" and zt='{$zt}'";
	        }
	        if(!empty($type)){
	        	$where.=" and fqcat='{$type}'";
	        }
	        
	        $day=date("Y/m/d",time());
            $dtime=strtotime($day);
	        
	        $page=$page;
            $pindex = max(1, intval($page));
		    $psize = 30;

            $list = pdo_fetchall("select * from ".tablename($this->modulename."_newtbgoods")." where weid='{$weid}' and couponendtime>={$dtime} {$where} order by {$orde} LIMIT " . ($pindex - 1) * $psize . ",{$psize}");
            $total = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename($this->modulename.'_newtbgoods')." where couponendtime>={$dtime} and  weid='{$weid}' {$where}");
            if(empty($list)){
				$status=2;
			}else{
				$status=1;//有数据
			}
			exit(json_encode(array('status' => $status, 'content' => $list,'lm'=>0)));
		}
		
?>
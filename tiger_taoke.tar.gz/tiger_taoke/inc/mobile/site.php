<?php
/**
 * 淘宝客帐号授权模块微站定义
 *
 * @author 老虎
 * @url http://bbs.we7.cc/
 */
defined('IN_IA') or exit('Access Denied');
require_once IA_ROOT . "/addons/tiger_shouquan/inc/tk/TopSdk.php";
require_once IA_ROOT . "/addons/tiger_shouquan/inc/phpanalysis2.0/phpanalysis.class.php";
class Tiger_shouquanModuleSite extends WeModuleSite {


       public function doMobileGengxin(){//更新软件
            $durl="http://cs.tigertaoke.com/addons/tiger_shouquan/rar/老虎淘宝客助手监控板.zip";
            $turl="http://cs.tigertaoke.com/addons/tiger_shouquan/rar/bg.txt";
            $bbh="3.200";
            die(urldecode(json_encode(array('v'=>$bbh,'updateLog'=>urlencode($turl),'url'=>urlencode($durl)))));   
        }


       public function doMobileFc(){//分词
           //http://cs.youqi18.com/app/index.php?i=3&c=entry&do=fc&m=tiger_shouquan&str=棉麻衬衫女帛色棉麻女装纯棉衬衫女%20长袖上衣文艺复古立领小衫
           global $_W, $_GPC;
           $str=$_GPC['str'];
           //$str='';
           //初始化类
            PhpAnalysis::$loadInit = false;
            $pa = new PhpAnalysis(); 
            //执行分词
            $pa->SetSource($str);
            $pa->resultType   = 1;
            $pa->differMax = false;
            $pa->unitWord = true;    
            $pa->StartAnalysis($do_fork);    
            $okresult = $pa->GetFinallyResult();
            return $okresult;         
       }


       


      
       public function getsq($url){

           $arr=array("http://cs.youqi18.com/","http://www.xiaohuaixuexi.com/","http://wx.kimant.cn/","http://www.qingchengxs.com/","http://huijuzhe.cn/","http://shuaimaimall.com/","http://www.xuanshigou.com/","http://www.baijiafei.com/","http://wx.1zh.cn/","http://agent1.baicl.cc/","http://ttlm.baicl.cc/","http://www.360baidu.net/","http://www.e-katong.com/","http://www.83fp.cn/","http://www.aldmg.com/","http://pt.guituapp.cn/","http://coupon.nayinianyun.com/","http://www.waalj.cn/","http://kk.duoshoulm.com/","http://www.ixysz.com/","http://wx.zhangxuncn.com/","http://t.cl95588.com/","http://taobao.vq58.com/","http://tao.wfx.la/","http://wx.vipdamai.com/","http://bxfree.cn/","http://wq.lc49.com/","http://xywgyh.yqlqdkf.com/","http://www.bingodeco.cn/","http://taobao.vq58.com/","http://mmm.vkeechina.com/","http://tao.julemai.com/","http://mmm.vkeechina.com/","http://tao.julemai.com/","http://i.tb666.com/","http://pulshain.com/","http://ruyifushi.cn/","http://www.a9sh.com/","http://tao.cnnsn.com/","http://www.alifanli.cc/","http://i.qipaz.com/","https://sc.350gf.com/","http://www.zhongjiwx.com/","http://www.99la.cn/","http://www.sdaini.com/","http://1.ailgou.com/","http://www.egou66.com.cn/","http://www.yuli360.com/","http://www.weimeng.me/","http://qingsonghuigou.com/","http://itaoquan.com.cn/","http://wq.ipcps.com/","http://www.ipcps.com/uploadweiqing/","http://www.365dzq.com/","http://www.eget.live/","http://www.365dzq.com/","http://www.8b6b.com/","http://www.eget.live/","http://www.8b6b.com/","http://wx.59160.net/","http://wx.taoai.biz/","http://bb.luohee.com/","http://www.ttwangou.com/","http://bb.luohee.com/","http://www.jinxiubuluo.com/","http://mshatuan.com/","http://daili.uhitao.cn/","http://shark.ahuowang.com/","http://www.passboat.cn/","http://daili.uhitao.cn/","http://www.duguole.com/","http://www.syshanghang.com/","http://tk.mamiwork.com/","http://mp.fulimai.com/","http://tao.zhidazhan.cn/","http://i.leewei.com.cn/","http://www.71ed.com/","http://www.goumiaosha.com/","http://www.588duobao.com/","http://we7.vipwshop.com/","http://vipwshop.com/","http://tb.38zz.com/","http://www.wzfl8.com/","http://lookf.cn/","http://www.fuli-mall.com/","http://wx.qiyitop.com/","http://youhuiquan80.cn/","http://wq.chengxindianshang.com/","http://www.lexianganyi.cn/","http://tk.taojinjuan.com/","http://tb.benditejia.com/","http://0534.qingyuntongcheng.com/","http://webe.9fen.net/","http://s.xn127.com/","http://wx.ymguniang.com/","http://178huigo.com/","http://www.pptaobao.com/","http://www.entr168.com/","http://m.banjiajie.com/","http://asz.05160321.com/","http://www.yidbao.com/","http://yiqupin.com/","http://yinno.cn/","http://t.218315.com/","http://v.cfrtv.com/","http://tianmaoquan.shop/","http://www.wei313.com/","http://118.190.40.115/","http://tb.quanlingling.com/","http://mt.baicl.cc/","http://www.c3j8.com/","http://tb.quanlingling.com/","http://www.kzqzq.cn/","http://www.c3j8.com/","http://www.gm218.com/","http://weixin.fuwu.shengjiesw.com/","http://www.haipigou.top/","http://11ju.win/","http://joegty.gotoip11.com/","http://www.zhe24.com/","http://wanxinpx.com/","http://wx.weitaoz.com/","http://crm.reduad.com/","http://taobao.jxweixin.cc/","http://zhouyueting.com/","http://wx.z0790.com/","http://www.huihuizhushou.com/","http://ma.taoke1818.com/","http://wz.ijiewen.cn/","http://tk.tuhuoyanghuo.com/","http://www.hanfeishi.com.cn/","http://jf.8090hz.net/","http://turdi.weibaza.com/","http://we.xiaoquandangjia.com/","http://www.360jiaodu.com/","http://mp.haopinku.com/","http://www.1khg.com/","http://wx.uegou88.com/","http://www.521fx.com/","http://hxndzsw.com/","http://www.7314011.com/","http://www.58wsl.com/","http://www.yataitv.com/","http://taoke.goodkz.cn/","http://taoke.benhuisc.cn/","http://www.xintaibaobao.com/","http://www.taotaoquan006.com/","http://weiqing.aituizhuan.com/","http://daili.hvwo.com/","http://www.hanguoqb.com/","http://wx.nd4.cn/","http://a.faneryigou.com/","http://ermao.bixente.com.cn/","http://wx1488.com/","http://tk.hpy868.com/","http://dayday1111.com/","http://www.c0317.com/","http://m.feels258.com/","http://7hxx.com/","http://paopao.haoshipu.net/","http://vx.fy80.net/","http://www.fytaohuigou.com/","http://www.91fanli.net/","http://www.jiefengyun.com/","http://wx.wandamc.com/","http://tk.liaoyunying.com/","http://wz.zdfan.com/","http://sklnhu.com/","http://www.leweibang.com/","http://tk.360pm.com.cn/","http://118.193.251.14/","http://yhcrew.cn/","http://www.shengmigou.cn/","http://www.taobao9877.com/","http://weixin.fulidodo.com/","http://yimian.bjhexing.com.cn/","http://www.cnsabvoton.com.cn/","http://tk.xiaozhibbs.com/","http://www.chaoyougou.cn/","http://www.taodabaicai.com/","http://dahuabb.com/","http://www.baicaihui.top/","http://wx.dgweiyue.com/","http://www.quanchaoduo.com/","http://tb.win-4g.com/","http://www.399yun.cn/","http://tk.mtzk920.com/","http://weil.xin/","http://wx.92tmh.com/","http://www.hyfc168.com/","http://www.lygzz.cn/","http://wx.utuoke.com/","http://dm.bayuecps.com/","http://mywxwz.dacuqu.cn/","http://we7git.hhappkf.com/","http://wjf.shwxo2o.com/","http://admin.ds-xt.com/","http://tk.360yzk.cn/","http://www.jigaocaisui.cn/","http://www.xunbiaosc.com/","http://ziwopai.com.cn/","http://www.renbaoman.com/","http://weixin.fobtech.cn/","http://tk.chen0735.top/","http://wx.bx0414.net/","http://wx.hskj123.com/","http://wq.io2oi.com/","http://www.163online.cn/","http://www.howork.com/","http://www.k443.com/","http://www.hexinyuwen.cn/","http://blbl999.cn/","http://www.api23.com/","http://i.taoks.net/","http://www.gaotangw.com/","http://wx.tao5a.net/","http://wx.258xg.cn/","http://www.992gouwu.com/","http://www.vooggoov.com/","http://wx.dhmclub.com/","http://wq.8848z.com/","http://mingpingzhe.com/","http://gzh.youxiangzhe.com/","http://svip.huanletao8.com/","http://m.liqunw.com/","http://wqadmin.fanlicool.com/","http://www.taokkj.com/","http://tk.kkp.hk.cn/","http://weixin.ok6k.com/","http://xuankaiyu.top/","http://renrentuike.com/","http://wxtbk.yqlqdkf.com/","http://www.bkyp.shop/","http://qlama.com/","http://weixin.hzbin.com/","http://wx.v3abc.com/","http://www.iliebuy.com/","http://wx.hnys0898.com/","http://www.nengoo.cn/","http://8111536.cn/","http://maiimai.com/","http://a.aituwang.cn/","http://wq.tongcheng95.com/","http://www.fankale.com/","http://www.juanqiang.com/","http://tmg.cgbha.com/","http://tk.tttql.com.cn/","http://mk.jhwt2688.com/","http://wq.mc48666.com/","http://qlt.s8cs.cn/","http://wei.xiedei.cn/","http://csfzmy.ichaozhi.cn/","http://www.duomai123.com/","http://tb.51cydb.com/","http://dlweilife.com/","http://wx.duoshoulm.com/","http://www.iohome.top/","http://wytaoke.com/","http://tk.loho5.com/","http://tbk.bixente.com.cn/","http://1981art.cn/","http://www.mengmengfanli.com/","https://weixin.conwos.com/","http://tbk.wxlljd.com/","http://wjy.zhcs.cn/","http://weizhuan.yunadm.com/bak/","http://bf.handiyar.com.cn/","http://jx.wzapi.com/","http://www.cqwm.cn/","http://www.zhongtaogo.com/","http://wx.ajjw.com/","http://tk.zheker.cn/","http://wx.ajjw.com/wx/","http://www.wuyuezhe.com/","http://yhq.baowuka.com/","http://wks.frwj.cn/","http://www.iheizun.cn/","http://365legou.net/","http://wx.qmlan.com/","http://mu.mumuyigou.com/","http://z.wzapi.com/","http://www.shitou8.cn/","http://www.i88888888.com/","http://www.52yungouwu.com/","http://www.0757live.com/","http://123.vgj.cc/","http://tk.kufu100.com/","http://weixin.0515idc.com/","http://w.zhegood.com/","http://shop.youwojiugou.com/","http://775km.cn/","http://888.lj778.com/","http://6ak.net/","http://city365.ilocals.cn/","http://sunigou.wzapi.com/","http://wx.208y.com/","http://xff.taoke1818.com/","http://www.smach.com.cn/","http://wx.love356.com/","http://w7.meitaobuy.com/","http://tb.zuanxiaobao.cn/","http://www.52sqm.com/","http://wx.renshenwenxiaochu.com/","http://54xinqingnian.com/","http://www.taolangke.com/","http://www.xcxkzy.com/","http://qxcong.top/","http://quan.aihuasuan.cn/","http://www.ulogou.com/we8","http://www.taoda.net/","http://wq.neibutejia.com/","http://wx.7sego.com/","http://wx.zhuodashi.net/","http://xuejiao.wzapi.com/","http://wei.metoovip.com/","http://www.taoyigou6.com/","http://wei.zhou1go.com/","http://www.ahxuetang.com/","http://tb.theseway.com/weixin/","http://www.aliheike.com/","http://agent.baicl.cc/","http://fl.huasuanwang.com/","http://wx.koudaimmt.com/","http://my.zjcnvp.com/","http://dfzd.ruitangnet.com/","http://www.dinina.com.cn/","http://wap.shengxianjin.com/","http://www.quanmiling.com/","http://w.s7t.cn/","http://tmall.youbaiye.cn/","http://wx.htgo8.com/","http://weixin.mangtai.com/","http://www.tix-c.com/","http://www.quanzhanggui.cn/","http://wx.dedecrm.com/","http://www.haoxuanhui.com/","http://yslmu.com/","http://go.ntguan.com/","http://weixin01.xingmiwang.com/","http://www.0754ch.cn/open/","http://taobao.5864vip.com/","http://wx.vtiantai.cn/","http://wx.yunjifushi.com/","http://www.aits168.cn/","http://gou.taomaopin.com/","http://www.taitaipa.cn/","http://wx.wangyeba.com/","http://www.ttflm.cn/weiqing","http://www.bangejia.com/","http://dianying.wdlaks.com/","http://tao.youhuigj.com/","http://xpb.pangmeizhi.com/","http://qt.duanchuanxu.com/","http://xpb.cauu.cn/","http://www.olinebao.com/","http://wx.51letaoquan.com/","http://quan.wanquanshu.com/","http://wx.qwb66.com/","http://jiukuaiduo.com/","http://s.zhekb.com/","http://www.i-loveyou.net.cn/","http://m.taojuba.com/","http://www.baiyitianshi.net.cn/","http://www.a0692.cc/","http://w7.miaoshadashi.com/","http://ht.zhangmazi.net/","http://www.taolehui.cc/","http://zavbv.cn/","http://www.vvg9.com.cn/","http://tao.vds789.com/","http://wx.quan02.com/","http://www.tianxz.com/","http://fensi.mrysw.net/","http://www.yes528.com/","http://www.nxliyuan.com/","http://taoke.51type.com/","http://wx.miaifengye.cn/","http://love.0cc1.com/","http://www.xytk123.com/","http://wx.topwx.cc/","http://www.de-dao.com/","http://ht.meichaofeng168.com/","http://weixin.haolailin.cn/","http://www.592zk.com/","http://egou66.cn/","http://huangfei.zhanpe.cn/","http://wq.91sq.vip/","http://hecheng.mianfeixueche.com/","http://xinjiang.zhanpe.cn/","http://baiye.zhanpe.cn/","http://888.shenla.com.cn/","http://weixin.msfs.cc/","http://w7.ycvw.com/","http://maoshouzhekou.com/","http://gzh.jianpe.com/","http://tk.zhongmaibao.cn/","http://zhengyuanbao.com/","http://wtk.xzcmkj.com/","http://aigou.yqlqdkf.com/","http://kk.wzapi.com/","http://wx.laibakeji.com/","http://xiao.weciyo.com/","http://xx.77win.cn/","http://zhq.zhanpe.cn/","http://tsxxw.zhanpe.com/","http://www.mekppa.cn/","http://weixin.zhanpe.com/","http://wx.huanshi.org/","http://mp.sygd.tv/","http://vip.zqwifi.com/","http://www.519133.com/","http://wechat.chanit.cn/","http://fx.weixine.net/","http://wx.iwangtai.com/","http://shengduoduo.cc/","http://www.weishanglaili.com/","http://fansg.com/","http://www.yescs.cn/","http://www.binna.cc/","http://sucailife.com/","http://www.thanks1618.cn/","http://www.rrm1688.com/","http://wx.qianxingwl.com/","http://i.weiks.net/","http://www.882km.com/","http://www.i-io2o.com/","http://www.bizhetu.com/","http://wq.weimiaodian.cn/","http://hd58.net/","http://tk.aycds.com/","http://www.x.aycds.com/","http://weixin.1024laosiji.com/","http://www.51ibeacons.com/","http://tk.feshion.cn/","http://wx.yyzhongxun.com/","http://www.ccccck.cn/","http://wei.yunmor.com/","http://wx.xixiwm.com/","http://wz.fenwx.com/","http://wq.1109wx.cn/","http://www.gnxgj.cn/","http://we7.xinhuashudian.cn/","http://miaofen.hbhuahuo.com/","http://www.jzegw.cn/","http://wx.dhwych.com/","http://dhwych.duapp.com/","http://www.baiban123.com/","http://tmall.fensigou.cc/","http://www.tceg.cc/","http://we.5i1515.com/","http://www.nabaowan.cn/","http://weixin.popok.cn/","http://a.nihaowu.cn/","http://rrd.huawenwx.com/","http://weitaowangluo.com/","http://www.whwpt.cc/","http://www.ixmdd.com/","http://o2o.neidonghao.com/","http://www.konblis.com/","http://www.1hok.com/","http://laizhuayu.com/","http://tao.yerhe.com/","http://weixin.dn58.cn/","http://yoolop.com/","http://weixin.vjh365.com/","http://saileihudong.com/","http://fly.szbym.com/","http://wq.peishang.cn/","http://www.czg666.com/","http://wq1.greenidtech.com/","http://wei.qianmengdian.com/","http://wz.juxinyan.com/","http://www.juweinong.cn/","http://weitaoketao.applinzi.com/","http://www.guoziguo.com/weixin/","http://www.kumiaojie.com/","http://lataoke.cn/","http://tk.x186.top/","http://www.okpk.cc/","http://wx.166cj.com/","http://8048.xin/","http://www.feiyaotao.com/","http://www.mouyanhuo.com/","http://www.zanbbs.com/","http://www.qundd.cn/","http://yixintj.cn/","http://tk.fhhz.net/","http://svip.buluoqq.com/","http://www.wankumall.com/","http://paodanlianmeng.com/","http://vip.0ogou.com/","http://www.anyrepeater.com/","http://www.zhongduanmai.com/","http://wei.wandhi.com/","http://www.azhangdashi.com/","http://wx.zhouhaibo.net/","http://www.2rangli.com/","http://www.765214.com/","http://www.iqcdn.com/","http://www.yida1050.com/","http://v.sdyulin.com/","http://www.wechoice.vip/","http://www.cndunhuang.net/","http://tbk.zhibofans.com/","http://igo.meitianmiao.com/","http://wx.uushanxi.com/","http://tk.bjwght.com/","http://ke.ituming.com/","http://www.ruofeng123.com/","http://yunmaozhekou.yqj688.com/","http://www.htpcq.com/","http://tk.806yao.com/","http://mmk.quandajie.cn/","http://wei.zhuangle.cc/","http://wap.iyhquan.com/","http://wayoupin.com/","http://shop.bbbian.com/","http://m.wyjx100.com/","http://www.sosodv.com/","http://wq.sinpking.com/","http://www.sdtong1918.com/","http://www.00ee.top/","http://gwcxl.com/","http://www.sx712.com/","http://www.tjcba.com/","http://wap.iyhquan.com/","http://v.quanniuniu.com/","http://tt.bjdkfeng.com/","http://wx.douyacai365.com/","http://wx.zheyili.xyz/","http://v.zheyili.com/","http://www.97vkayun.com/","http://ybslkj.com/","http://www.pandaby.cn/","http://88.wzapi.com/","http://m.0512aist.com/","http://www.appsc.vip/","http://hlshgou.com/","http://www.hlshgou.com/","http://h.ltaomi.com/","http://taobao.jaylan.cn/","http://www.0735bx.com/","http://tbk.vipshw.net/","http://hjumall.com/","http://www.qhdao.net/","http://fx.123gou.me/","http://we7.quanmaidan.com/","http://tao.vipidcard.com/","http://w.aue8.com/","http://tk.altyh.com/","http://www.zlitao.cn/","http://wx.weibao123.cn/","http://taoke.ddgo.cc/","http://www.aiyi.hk.cn/","http://www.c0795.com/","http://top.hjumall.com/","http://i.taokehai.com/","http://www.yc0509.com/","http://3.j88k.cn/","http://116.62.127.161/wp-admin","http://www.gnmxt.com/","http://wx.xiaojuse.com/","https://xinbaozhang.com/","http://wx.shiguangvip.com/","http://www.taopianyi.club/","http://www.ma22ma.com/","http://www.youhuiyoupin.com/");
           if(in_array($url,$arr)){
              return 1;// '授权';
           }else{
              return 2;//echo '未授权';
           }
       }


       


       public function doMobileToken(){
       global $_W, $_GPC;
       //https://oauth.taobao.com/authorize?response_type=code&client_id=23533320&redirect_uri=http://cs.youqi18.com/addons/tiger_shouquan/tkapi.php?i=3&state=1212&view=web

       //https://oauth.taobao.com/authorize?response_type=code&client_id=23533320&redirect_uri=http://cs.youqi18.com/addons/tiger_shouquan/tkapi.php?i=3&state=http://cs.youqi18.com|3&view=web

       //http://cs.youqi18.com/app/index.php?i=3&c=entry&do=tksign&m=tiger_taoke&sign=111&tbuid=222&endtime=333&op=post
       //header("location:".$url);

       
       
         $fhurl=explode("|",$_GPC['state']);
         $furl=$fhurl[0];
         $fwid=$fhurl[1];
//         print_r($fhurl);
//         echo "<pre>";
//         print_r($_GPC);
//         exit;

         $code=$_GPC['code'];
         $state=$_GPC['state'];
         $weid=$_GPC['i'];

         $url = 'https://oauth.taobao.com/token';
         $postfields= array('grant_type'=>'authorization_code',
         'client_id'=>'23533320',
         'client_secret'=>'3b1871cb89c0ff2679759a57c51dfe18',
         'code'=>$_GPC['code'],
         'redirect_uri'=>'http://cs.tigertaoke.com/addons/tiger_shouquan/tkapi.php?i=3');
         $post_data = '';
         
         foreach($postfields as $key=>$value){
         $post_data .="$key=".urlencode($value)."&";}
         $ch = curl_init();
         curl_setopt($ch, CURLOPT_URL, $url);
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
         curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
         curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
         
         //指定post数据
         curl_setopt($ch, CURLOPT_POST, true);

         //添加变量
         curl_setopt($ch, CURLOPT_POSTFIELDS, substr($post_data,0,-1));
         $output = curl_exec($ch);
         $httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
         //echo $httpStatusCode;
         curl_close($ch);

       //echo "<pre>";
       $resp=json_decode($output,TRUE);
       //print_r($resp);
       

       $data=array(
           'weid'=>$weid,
           'code'=>$code,
           'state'=>$state,
           'taobao_user_nick'=>$resp['taobao_user_nick'],
           're_expires_in'=>$resp['re_expires_in'],
           'expire_time'=>$resp['expire_time'],
           'r1_expires_in'=>$resp['r1_expires_in'],
           'w2_valid'=>$resp['w2_valid'],
           'w2_expires_in'=>$resp['w2_valid'],
           'taobao_user_id'=>$resp['taobao_user_id'],
           'w1_expires_in'=>$resp['w1_expires_in'],
           'r1_valid'=>$resp['r1_valid'],
           'r2_valid'=>$resp['r2_valid'],
           'w1_valid'=>$resp['taobao_user_nick'],
           'r2_expires_in'=>$resp['r2_expires_in'],
           'token_type'=>$resp['token_type'],
           'refresh_token'=>$resp['refresh_token'],
           'refresh_token_valid_time'=>$resp['refresh_token_valid_time'],
           'access_token'=>$resp['access_token'],
           'createtime' => TIMESTAMP
       );

        $go = pdo_fetch("SELECT id FROM " . tablename($this->modulename."_apitoken") . " WHERE  taobao_user_id='{$resp['taobao_user_id']}'");
        if(empty($go)){
              $res=pdo_insert($this->modulename."_apitoken",$data);
              if($res=== false){
                Return json_encode(array('error'=>'1'));//授权失败
              }else{
                $arr=array(
                      'expire_time'=>$resp['expire_time'],
                      'taobao_user_id'=>$resp['taobao_user_id'],
                      'access_token'=>$resp['access_token'],
                      'furl'=>$furl,
                      'fwid'=>$fwid,
                );
                Return json_encode($arr);
              }
        }else{                          
              $res=pdo_update($this->modulename."_apitoken", $data, array('taobao_user_id' =>$resp['taobao_user_id']));
              if($res=== false){
                Return json_encode(array('error'=>'1'));//授权失败
              }else{
                 $arr=array(
                      'expire_time'=>$resp['expire_time'],
                      'taobao_user_id'=>$resp['taobao_user_id'],
                      'access_token'=>$resp['access_token'],
                      'furl'=>$furl,
                      'fwid'=>$fwid,
                );
                Return json_encode($arr);
              }
        }  
        exit;

       /*
       Array
(
    [taobao_user_nick] => hu275410734
    [re_expires_in] => 0
    [expires_in] => 2592000 //30天
    [expire_time] => 1494509902039 到期时间戳
    [r1_expires_in] => 2592000 //30天
    [w2_valid] => 1491919702039  //生成时间
    [w2_expires_in] => 1800
    [taobao_user_id] => 32035371 //淘宝UID
    [w1_expires_in] => 2592000 //30天
    [r1_valid] => 1494509902039
    [r2_valid] => 1492177102039
    [w1_valid] => 1494509902039
    [r2_expires_in] => 259200
    [token_type] => Bearer
    [refresh_token] => 70003100a438544ba6c36765b8a0f59d1b68ae0f3e09207692f68af1529950e151f06fa32035371
    [refresh_token_valid_time] => 1491917902039
    [access_token] => 70002100c4344973c568947b050a95b837ee779ef609ca743f34fe4149614dad51cb59e32035371
)
       */
   
   
   }


   public function doMobiletktoApi() {//软件获取TOKEN
      global $_W, $_GPC;
      $tbuid=$_GPC['tbuid'];
      $tkurl=$_GPC['tkurl'];

      $token=pdo_fetch("SELECT access_token FROM " . tablename($this->modulename."_apitoken") . " WHERE  taobao_user_id='{$tbuid}'");
      if(empty($token['access_token'])){
         die(json_encode(array('error'=>'请先到后台授权！','sign'=>'')));
      }else{
         die(json_encode(array('error'=>'','sign'=>$token['access_token'])));
      }
   }


     public function getdb($url){//盗版程序
           $arr=array('http://www.wenyimsn.com/','http://www.yythreehigh.com/','http://shangmeilife.com/','http://www.changek.com/','http://shengmigou.cn/','http://cyyswl.com/','http://yu.taoyoujuan.com/','http://biao.ligouba.cn/','http://lilin.ligouba.cn/','http://mp.weiana.cn/','http://www.szxiexie.cn/','http://juyiz.com/','http://www.91jianlou.com/',"http://www.yizhe666.com/");
           if(in_array($url,$arr)){
              return 2;// '盗版域名';
           }
       } 
       //无需设置 157961089 82098939 53017238 37557241 2075350424 3204685667 3305075198 844981334 20632287 2883840922 3270588411 388990993 2690915208 1110892461 805010863 3280714239 815653903  2315216024 654051579 213287164 3214592862 764718690 826245252 2955749915 662458754 322913920 653414334 74870324 534680655 185765653 677818421 620227655 484007142 72399469 2628617692 258988473 273964095 150175334 467877 96568476 3166092069 450245623 2196223116 652387169  84762090 590148075 354794205 604025418 511451072

       //怀疑盗版 41425005 736263053  631016272 238288761
       //明确盗版 2735516531
       //盗版已经购买 394769825 69930156 2003435896 2302026842 69930156 2302026842 358204743 31711189 2586559029 262854830 2845600325 33716444
       //若晨社区盗版 rocrm.cn 368911412 3310857829 341973559
       public function getdbid($tbid){//盗版程序淘宝ID
           $arr=array('2881891169','826008729','408891197','2287322436','3025792091','3197539422','3216320099','2841990726','3209907566','1656306118','785279444','2157953038','162811143','652772880','1689242831','2448705158','1993836197','3104527358','3163217018','158445122','696310809','917360429','1754055446','2502230957','2073496705','726615053','202585895','2638891427','1742877724','894630117','98325669','2627652028','854727352','3099945901','3167358485','2894270526','1022199683','142718341','2502632051','834342886','1097391665','670893930','1123985205','2733987611','53035746','2380431615','395370573','154636916','372977853','748220671','2735516531','744248647','2253461228','811285215','368911412','3310857829','341973559');
           if(in_array($tbid,$arr)){
              return 2;// '盗版域名';
           }
       }




    public function doMobiletkApi(){
        global $_W, $_GPC;
        $numid=$_GPC['numid'];
        $adzoneid=$_GPC['adzoneid'];
        $siteId=$_GPC['siteId'];
        $sign=$_GPC['sign'];
        $tbuid=$_GPC['tbuid'];
        $tkurl=$_GPC['tkurl'];
        $tkip=$_GPC['tkip'];
        $sq=$_GPC['sq'];  //1正确  2盗版
        $me=$_GPC['me'];//营销计划ME参数优先
        $tkurl=$tkurl."/";
        if(empty($tkurl)){
          //die(json_encode(array('error'=>'请更新到最新版！')));
        }

        $dbtbid=$this->getdbid($tbuid);
        if($dbtbid==2){
          die(json_encode(array('error'=>'请联系老虎更新到最新版：QQ:1640226229!')));
        }

        $db=$this->getdb($tkurl);
        if($db==2){
           die(json_encode(array('error'=>'请联系老虎更新到最新版：QQ:1640226229!')));
        }
        



        $zt=$this->getsq($tkurl);
        if($zt==2){
          //die(json_encode(array('error'=>'请更新到最新版！无法更新，请联系老虎：1640226229（购买正版程序）')));
          //file_put_contents(IA_ROOT."/addons/tiger_shouquan/db.txt","\n".json_encode($tbuid.'----'.$tkurl.'--->'.$sq),FILE_APPEND);
          
          //file_put_contents(IA_ROOT."/addons/tiger_shouquan/log.txt","\n old:".json_encode($tbuid.'-'.$sign.'--'.$tkurl.'--'.$tkip),FILE_APPEND);
        }
        

        
        if(empty($numid) || empty($adzoneid) || empty($siteId) || empty($sign)){
          die(json_encode(array('error'=>'请检查PID和云控授权！')));
        }
        

        

        $c = new TopClient;
        $c->appkey = '23533320';
        $c->secretKey = '3b1871cb89c0ff2679759a57c51dfe18';
        $req = new TbkPrivilegeGetRequest;
        $req->setItemId($numid);//商品ID
        $req->setAdzoneId($adzoneid);
        $req->setPlatform("1");
        $req->setSiteId($siteId);
        if(!empty($me)){
        	$req->setMe($me);
        }    
        $resp = $c->execute($req,$sign);
        //echo '<pre>';
            
        $resp=json_decode(json_encode($resp),TRUE);

        if(empty($sq)){
          $sq=0;
        }

        file_put_contents(IA_ROOT."/addons/tiger_shouquan/log/".$sq."-------".$tbuid.".txt","\n old:".json_encode($tbuid.'-'.$sign.'--'.$tkurl.'--'.$tkip),FILE_APPEND);



        file_put_contents(IA_ROOT."/addons/tiger_shouquan/mamapi.txt","\n--sq:".$sq."--tbid:".$tbuid."--ad:".$adzoneid."--si:".$siteId."--".$tkurl."-SIGN:".$sign."".json_encode($resp),FILE_APPEND);
        $goods=$resp['result']['data'];
        if(!empty($goods)){
           preg_match_all('|满([\d\.]+).*元减(.*)元|ism', $goods['coupon_info'], $returnArr);
           //file_put_contents(IA_ROOT."/addons/tiger_shouquan/mamapi.txt","\n--yhj---".json_encode($returnArr[2][0]),FILE_APPEND);
           $goods['money']=$returnArr[2][0];//优惠券金额
           $goods['xemoney']=$returnArr[1][0];//满多少
           //file_put_contents(IA_ROOT."/addons/tiger_shouquan/mamapi.txt","\n-".$tbuid."--".json_encode($goods),FILE_APPEND);
           die(json_encode($goods));
        }else{
           if(empty($resp['sub_msg'])){
              die(json_encode(array('error'=>'云控请重新授权！')));
           }else{
              die(json_encode(array('error'=>$resp['sub_msg'])));
           }
           
        }
        //print_r($resp);
       /*
       $resp['result']['data']=Array
        (
            [category_id] => 16
            [coupon_click_url] => https://uland.taobao.com/coupon/edetail?e=9Tw9M25HPb9t3vqbdXnGllqnggAIWDWcttG4Yw5ao1n1REHYujyL%2FWzbfL9YYAq%2BNSftvmi7a%2FPUQqEGiQFpyP7oZbZWOzqooUC34ijeiBthN89Lb%2BEzCzVC0SEP1L7d&pid=mm_27386314_17768214_64066386&af=1&itemId=546715626716
            [coupon_end_time] => 2017-04-13
            [coupon_info] => 满5元减5元
            [coupon_remain_count] => 200
            [coupon_start_time] => 2017-04-10
            [coupon_total_count] => 1000
            [item_id] => 546715626716
            [max_commission_rate] => 30.00
        )

       $resp=Array
        (
            [code] => 27
            [msg] => Invalid session
            [sub_code] => invalid-sessionkey
            [request_id] => 10wjkw7ia2bcv
        )
        */  
    }

//    public function doMobileGoods(){//联盟产品
//         
//
//            $c = new TopClient;
//            $c->appkey = '23533320';
//            $c->secretKey = 'a475f03826ca2f1918509b3b655b6e2a';
//            $req = new TbkItemCouponGetRequest;
//            $req->setPlatform("2");//无线端
//            //$req->setCat("16,18");
//            $req->setPageSize("20");//一页几个
//            $req->setQ("女装");
//            $req->setPageNo("1");//页数
//            $req->setPid("mm_123_123_123");
//            $resp = $c->execute($req);
//            $resp=json_decode(json_encode($resp),TRUE);
//            echo '<pre>';
//            print_r($resp);
//            exit;
//    }

    public function doMobileGoodsindex(){//联盟商品库首页产品
       global $_W, $_GPC;
       //http://cs.youqi18.com/app/index.php?i=3&c=entry&do=goods&m=tiger_shouquan&key=衬衫&pid=1233&&page=3
       $key=$_GPC['key'];
       $pid=$_GPC['pid'];
       $page=$_GPC['page'];
       $tkurl=$_GPC['tkurl'];
       if(empty($page)){
         $page=1;
       }

       if(empty($pid)){
         return '填写PID';
       }
       $c = new TopClient;
       $c->appkey = '23533320';
       $c->secretKey = '3b1871cb89c0ff2679759a57c51dfe18';
       $req = new TbkItemCouponGetRequest;
       $req->setPlatform("2");
       //$req->setCat("16,18");
       $req->setPageSize("20");//每页几条
       $req->setQ($key);
       $req->setPageNo($page);//第几页
       $req->setPid($pid);
       $resp = $c->execute($req);
       $resp=json_decode(json_encode($resp),TRUE);
       $goods=$resp['results']['tbk_coupon'];

       /**
        {
            "title": "宠爱之名亮白净化生物纤维面膜 美白面膜提亮补水保湿抗皱女台湾",
            "istmall": "1",
            "num_iid": "528837404221",
            "url": "http://uland.taobao.com/coupon/edetail?e=j7aQhQZWWBUGQASttHIRqVDZ2%2FczCmrC2ElzakwnsL4h4%2FBFCEkLWJeWvsdpVjrylR9LEFf6gAunPxi3vqFQFsKW%2BjRrFWjpDfqEFBOhTczGXK8FKE%2Belk6op9WxBu6puPhs5UT0csDYzTcxFGvzsx%2Fc4wpj4S5KQ4XS9FheCPfNWdzmw3WZLg%3D%3D",
            "coupons_end": "2017-05-31",
            "coupons_price": "10",
            "goods_sale": "55",
            "price": 275,
            "org_price": "285.00",
            "pic_url": "http://img1.tbcdn.cn/tfscom/i1/TB1d0NKRXXXXXXlXVXXXXXXXXXX_!!0-item_pic.jpg",
            "shop_title": "宠爱之名海外旗舰店",
            "tk_rate": "16.00",
            "nick": "宠爱之名海外旗舰店",
            "coupons_take": "9641",
            "coupons_total": "10000",
            "item_url": "http://item.taobao.com/item.htm?id=528837404221",
            "small_images": [
                "http://img2.tbcdn.cn/tfscom/i3/TB1izQxPVXXXXbkapXXXXXXXXXX_!!0-item_pic.jpg",
                "http://img4.tbcdn.cn/tfscom/i1/TB1H8yQPVXXXXa9XVXXXXXXXXXX_!!0-item_pic.jpg",
                "http://img2.tbcdn.cn/tfscom/i4/2843511765/TB2um56a1rAQeBjSZFNXXcgJVXa_!!2843511765.jpg",
                "http://img4.tbcdn.cn/tfscom/i1/2843511765/TB2xD_FcmiJ.eBjSspiXXbqAFXa_!!2843511765.jpg"
            ]
        }
       **/

//       $list[]=array(
//               'title'=>'测试名称女台湾',
//               'istmall'=>1,
//               'num_iid'=>'528837404221',
//               'url'=>'http://uland.taobao.com/coupon/edetail?e=j7aQhQZWWBUGQASttHIRqVDZ2%2FczCmrC2ElzakwnsL4h4%2FBFCEkLWJeWvsdpVjrylR9LEFf6gAunPxi3vqFQFsKW%2BjRrFWjpDfqEFBOhTczGXK8FKE%2Belk6op9WxBu6puPhs5UT0csDYzTcxFGvzsx%2Fc4wpj4S5KQ4XS9FheCPfNWdzmw3WZLg%3D%3D',
//               'coupons_end'=>"2017-05-31",
//               'coupons_price'=>"10",
//               'goods_sale'=>"55",
//               'price'=>275,
//               'org_price'=>"285.00",
//               'pic_url'=>"http://img1.tbcdn.cn/tfscom/i1/TB1d0NKRXXXXXXlXVXXXXXXXXXX_!!0-item_pic.jpg",
//               'shop_title'=>"宠爱之名海外旗舰店",
//               'tk_rate'=>"16.00",//佣金比例
//               'nick'=>"宠爱之名海外旗舰店",
//               'coupons_take'=> "9641",
//               'coupons_total'=>"10000",
//               'item_url'=>"http://item.taobao.com/item.htm?id=528837404221",
//               'small_images'=>'',
//           );


       foreach($goods as $k=>$v){
          $tkyj=intval($v['commission_rate']);
          if($tkyj<16){
            continue;
          }
         
//         $list[$k]['title']=$v['title'];
//         $list[$k]['istmall']=$v['user_type'];
//         $list[$k]['num_iid']=$v['num_iid'];
//         $list[$k]['url']=$v['coupon_click_url'];
//         $list[$k]['coupons_end']=$v['coupon_end_time'];
//         preg_match_all('|满([\d\.]+).*元减([\d\.]+).*元|ism',$v['coupon_info'], $matches);
//         $list[$k]['coupons_price']=$matches[2][0];
//         $list[$k]['goods_sale']=$v['volume'];
//         $list[$k]['price']=$v['zk_final_price']-$matches[2][0];
//         $list[$k]['org_price']=$v['zk_final_price'];
//         $list[$k]['pic_url']=$v['pict_url'];
//         $list[$k]['shop_title']=$v['shop_title'];
//         $list[$k]['tk_rate']=$v['commission_rate'];//佣金比例
//         $list[$k]['nick']=$v['nick'];
//         $list[$k]['coupons_take']=$v['coupon_remain_count'];
//         $list[$k]['coupons_total']=$v['coupon_total_count'];
//         $list[$k]['item_url']=$v['item_url'];
//         $list[$k]['small_images']=$v['small_images']['string'];
//         $list[$k]['pic_url']=$v['pict_url'];

           preg_match_all('|满([\d\.]+).*元减([\d\.]+).*元|ism',$v['coupon_info'], $matches);
           $list[]=array(
               'title'=>$v['title'],
               'istmall'=>$v['user_type'],
               'num_iid'=>$v['num_iid'],
               'url'=>$v['coupon_click_url'],
               'coupons_end'=>$v['coupon_end_time'],
               'coupons_price'=>$matches[2][0],
               'goods_sale'=>$v['volume'],
               'price'=>$v['zk_final_price']-$matches[2][0],
               'org_price'=>$v['zk_final_price'],
               'pic_url'=>$v['pict_url'],
               'shop_title'=>$v['shop_title'],
               'tk_rate'=>$v['commission_rate'],//佣金比例
               'nick'=>$v['nick'],
               'coupons_take'=>$v['coupon_remain_count'],
               'coupons_total'=>$v['coupon_total_count'],
               'item_url'=>$v['item_url'],
               'small_images'=>$v['small_images']['string'],
           );

       }

       //file_put_contents(IA_ROOT."/addons/tiger_shouquan/mamapi--.txt","\n-".$tkurl."--".$key."-".$pid."--".$page."---".json_encode($list),FILE_APPEND);



      // echo '<pre>';
       //print_r($list);
       //exit;
       if(empty($list)){
          $err=1;
       }else{
          $err=2;
       }
       die(json_encode(array('error'=>$err,'list'=>$list)));
       //die(json_encode($list));
       //die(urldecode(json_encode(array('error'=>0,'list'=>$list))));
       //return $list;
   }

    public function doMobileGoods(){//联盟商品库
       global $_W, $_GPC;
       //http://cs.youqi18.com/app/index.php?i=3&c=entry&do=goods&m=tiger_shouquan&key=衬衫&pid=1233&&page=3
       $key=$_GPC['key'];
       $pid=$_GPC['pid'];
       $page=$_GPC['page'];
       $tkurl=$_GPC['tkurl'];
       if(empty($page)){
         $page=1;
       }

       if(empty($pid)){
         return '填写PID';
       }
       $c = new TopClient;
       $c->appkey = '23533320';
       $c->secretKey = '3b1871cb89c0ff2679759a57c51dfe18';
       $req = new TbkItemCouponGetRequest;
       $req->setPlatform("2");
       //$req->setCat("16,18");
       $req->setPageSize("20");//每页几条
       $req->setQ($key);
       $req->setPageNo($page);//第几页
       $req->setPid($pid);
       $resp = $c->execute($req);
       $resp=json_decode(json_encode($resp),TRUE);
       $goods=$resp['results']['tbk_coupon'];

       /**
        {
            "title": "宠爱之名亮白净化生物纤维面膜 美白面膜提亮补水保湿抗皱女台湾",
            "istmall": "1",
            "num_iid": "528837404221",
            "url": "http://uland.taobao.com/coupon/edetail?e=j7aQhQZWWBUGQASttHIRqVDZ2%2FczCmrC2ElzakwnsL4h4%2FBFCEkLWJeWvsdpVjrylR9LEFf6gAunPxi3vqFQFsKW%2BjRrFWjpDfqEFBOhTczGXK8FKE%2Belk6op9WxBu6puPhs5UT0csDYzTcxFGvzsx%2Fc4wpj4S5KQ4XS9FheCPfNWdzmw3WZLg%3D%3D",
            "coupons_end": "2017-05-31",
            "coupons_price": "10",
            "goods_sale": "55",
            "price": 275,
            "org_price": "285.00",
            "pic_url": "http://img1.tbcdn.cn/tfscom/i1/TB1d0NKRXXXXXXlXVXXXXXXXXXX_!!0-item_pic.jpg",
            "shop_title": "宠爱之名海外旗舰店",
            "tk_rate": "16.00",
            "nick": "宠爱之名海外旗舰店",
            "coupons_take": "9641",
            "coupons_total": "10000",
            "item_url": "http://item.taobao.com/item.htm?id=528837404221",
            "small_images": [
                "http://img2.tbcdn.cn/tfscom/i3/TB1izQxPVXXXXbkapXXXXXXXXXX_!!0-item_pic.jpg",
                "http://img4.tbcdn.cn/tfscom/i1/TB1H8yQPVXXXXa9XVXXXXXXXXXX_!!0-item_pic.jpg",
                "http://img2.tbcdn.cn/tfscom/i4/2843511765/TB2um56a1rAQeBjSZFNXXcgJVXa_!!2843511765.jpg",
                "http://img4.tbcdn.cn/tfscom/i1/2843511765/TB2xD_FcmiJ.eBjSspiXXbqAFXa_!!2843511765.jpg"
            ]
        }
       **/

//       $list[]=array(
//               'title'=>'测试名称女台湾',
//               'istmall'=>1,
//               'num_iid'=>'528837404221',
//               'url'=>'http://uland.taobao.com/coupon/edetail?e=j7aQhQZWWBUGQASttHIRqVDZ2%2FczCmrC2ElzakwnsL4h4%2FBFCEkLWJeWvsdpVjrylR9LEFf6gAunPxi3vqFQFsKW%2BjRrFWjpDfqEFBOhTczGXK8FKE%2Belk6op9WxBu6puPhs5UT0csDYzTcxFGvzsx%2Fc4wpj4S5KQ4XS9FheCPfNWdzmw3WZLg%3D%3D',
//               'coupons_end'=>"2017-05-31",
//               'coupons_price'=>"10",
//               'goods_sale'=>"55",
//               'price'=>275,
//               'org_price'=>"285.00",
//               'pic_url'=>"http://img1.tbcdn.cn/tfscom/i1/TB1d0NKRXXXXXXlXVXXXXXXXXXX_!!0-item_pic.jpg",
//               'shop_title'=>"宠爱之名海外旗舰店",
//               'tk_rate'=>"16.00",//佣金比例
//               'nick'=>"宠爱之名海外旗舰店",
//               'coupons_take'=> "9641",
//               'coupons_total'=>"10000",
//               'item_url'=>"http://item.taobao.com/item.htm?id=528837404221",
//               'small_images'=>'',
//           );


       foreach($goods as $k=>$v){
          $tkyj=intval($v['commission_rate']);
          if($tkyj<16){
            continue;
          }
         
//         $list[$k]['title']=$v['title'];
//         $list[$k]['istmall']=$v['user_type'];
//         $list[$k]['num_iid']=$v['num_iid'];
//         $list[$k]['url']=$v['coupon_click_url'];
//         $list[$k]['coupons_end']=$v['coupon_end_time'];
//         preg_match_all('|满([\d\.]+).*元减([\d\.]+).*元|ism',$v['coupon_info'], $matches);
//         $list[$k]['coupons_price']=$matches[2][0];
//         $list[$k]['goods_sale']=$v['volume'];
//         $list[$k]['price']=$v['zk_final_price']-$matches[2][0];
//         $list[$k]['org_price']=$v['zk_final_price'];
//         $list[$k]['pic_url']=$v['pict_url'];
//         $list[$k]['shop_title']=$v['shop_title'];
//         $list[$k]['tk_rate']=$v['commission_rate'];//佣金比例
//         $list[$k]['nick']=$v['nick'];
//         $list[$k]['coupons_take']=$v['coupon_remain_count'];
//         $list[$k]['coupons_total']=$v['coupon_total_count'];
//         $list[$k]['item_url']=$v['item_url'];
//         $list[$k]['small_images']=$v['small_images']['string'];
//         $list[$k]['pic_url']=$v['pict_url'];

           preg_match_all('|满([\d\.]+).*元减([\d\.]+).*元|ism',$v['coupon_info'], $matches);
           $list[]=array(
               'title'=>$v['title'],
               'istmall'=>$v['user_type'],
               'num_iid'=>$v['num_iid'],
               'url'=>$v['coupon_click_url'],
               'coupons_end'=>$v['coupon_end_time'],
               'coupons_price'=>$matches[2][0],
               'goods_sale'=>$v['volume'],
               'price'=>$v['zk_final_price']-$matches[2][0],
               'org_price'=>$v['zk_final_price'],
               'pic_url'=>$v['pict_url'],
               'shop_title'=>$v['shop_title'],
               'tk_rate'=>$v['commission_rate'],//佣金比例
               'nick'=>$v['nick'],
               'coupons_take'=>$v['coupon_remain_count'],
               'coupons_total'=>$v['coupon_total_count'],
               'item_url'=>$v['item_url'],
               'small_images'=>$v['small_images']['string'],
           );

       }

       //file_put_contents(IA_ROOT."/addons/tiger_shouquan/mamapi--.txt","\n-".$tkurl."--".$key."-".$pid."--".$page."---".json_encode($list),FILE_APPEND);



      // echo '<pre>';
       //print_r($list);
       //exit;
       if(empty($list)){
          $err=1;
       }else{
          $err=2;
       }
       die(json_encode(array('error'=>$err,'list'=>$list)));
       //die(json_encode($list));
       //die(urldecode(json_encode(array('error'=>0,'list'=>$list))));
       //return $list;
   }

    public function doWebSqlist() {
        global $_W, $_GPC;

          if(checksubmit('submitms')){//设置盗版
              if(!$_GPC['id']){
                message('请选择盗版用户', referer(), 'error');
              }
              foreach ($_GPC['id'] as $id){
                    $row = pdo_fetch("SELECT id FROM " . tablename($this->modulename.'_apitoken') . " WHERE id = :id", array(':id' => $id));
                    if (empty($row)){
                        continue;
                    }
                    pdo_update($this->modulename."_apitoken",array('dbtype'=>1), array('id' => $id));
                }
                message('批量盗版设置成功', referer(), 'success');
            }

            if(checksubmit('submitmsqx')){//取消盗版
              if(!$_GPC['id']){
                message('请选择秒杀商品', referer(), 'error');
              }
              foreach ($_GPC['id'] as $id){
                    $row = pdo_fetch("SELECT id FROM " . tablename($this->modulename.'_apitoken') . " WHERE id = :id", array(':id' => $id));
                    if (empty($row)){
                        continue;
                    }
                    pdo_update($this->modulename."_apitoken",array('dbtype'=>0), array('id' => $id));
                }
                message('批量取消盗版成功', referer(), 'success');
            }

            if($_GPC['dbtype']==1){
               $where=" and dbtype=1";
            }
            if(!empty($_GPC['name'])){
               $where.=" and state like '%{$_GPC['name']}%' || taobao_user_id='{$_GPC['name']}'";
            }




            $pindex = max(1, intval($_GPC['page']));
		    $psize = 1500;  
            $list = pdo_fetchall("SELECT * FROM " . tablename($this->modulename."_apitoken") . " WHERE weid='{$_W['uniacid']}' {$where} ORDER BY id desc LIMIT " . ($pindex - 1) * $psize . ",{$psize}");
            $total = pdo_fetchcolumn("SELECT COUNT(*) FROM " . tablename($this->modulename.'_apitoken')." where weid='{$_W['uniacid']}'  {$where} ");
		    $pager = pagination($total, $pindex, $psize);    
            include $this -> template('sqlist');
    }

	public function doMobileReg() {//登录
        global $_W, $_GPC;
        
            $username=trim($_GPC['username']);
            $password=md5(trim($_GPC['password']));
            if(empty($username) || empty($password)){
                //die(json_encode(array('error'=>1,'msg'=>"请输入帐号密码")));
                die(json_encode(array('error'=>1,'username'=>'','uid'=>'','msg'=>'请输入帐号密码')));
            }

            $set= pdo_fetch("SELECT * FROM " . tablename($this->modulename."_member") . " WHERE username='{$username}' and weid='{$_W['uniacid']}' ");
            //echo $password;
            //print_r($set);
            //echo $username."<br>";
            //echo $set['username']."<br>";
            //echo $password."1<br>";
            //echo $set['passwd']."2<br>";
            if($username==$set['username'] && $password==$set['passwd']){
                 die(json_encode(array('error'=>0,'username'=>$set['username'],'uid'=>$set['id'],'msg'=>'')));
            }else{
                 //die(json_encode(array('error'=>2,'msg'=>"帐号密码错误")));
                 die(json_encode(array('error'=>2,'username'=>'','uid'=>'','msg'=>'帐号密码错误')));
            }
            //print_r($_GPC);   
            exit;             
       
      
	}

    public function doMobileDelgoods(){
        global $_W, $_GPC;
        $uid=$_GPC['uid'];
        pdo_delete($this->modulename."_tbgoods", array('uid' =>$uid));
        exit('删除成功');

    }

    public function doMobilePostgoods(){
      global $_W, $_GPC;
        $goodsdata=$_GPC['goodsdata'];
        $num_iid=$_GPC['numiid'];
        $uid=$_GPC['uid'];
        if($uid=='666666'){
          exit('UID错误');
        }
        file_put_contents(IA_ROOT."/addons/tiger_shouquan/postgoods.txt","\n--tbid:".$goodsdata."--ad:".$num_iid."--si:".$uid."--".$tkurl."-".json_encode($resp),FILE_APPEND);

        $od=pdo_fetch("select * from ".tablename($this->modulename."_tbgoods")." where num_iid='{$num_iid}' and uid='{$uid}'");        
        if(empty($od)){
            $data=array(
                'goodsdata'=>$goodsdata,
                'num_iid'=>$num_iid,
                'weid'=>$_W['uniacid'],
                'uid'=>$uid,
                'createtime'=>TIMESTAMP,
            );
           pdo_insert($this->modulename."_tbgoods",$data);
        }else{
            $data=array(
                'goodsdata'=>$goodsdata,
                'num_iid'=>$num_iid,
                'weid'=>$_W['uniacid'],
                'uid'=>$uid,
                'createtime'=>TIMESTAMP,
            );
           pdo_update($this->modulename."_tbgoods", $data, array('num_iid' =>$num_iid,'uid'=>$uid));
        }
        exit('1');
    }

    public function doMobileGoodslist(){
      global $_W, $_GPC;
        $uid=$_GPC['uid'];
        $od=pdo_fetchall("select * from ".tablename($this->modulename."_tbgoods")." where uid='{$uid}'");  
        foreach ($od as $key => $value) {           
			$list1[$key]['goodsdata'] = urlencode($value['goodsdata']);
			$list1[$key]['numiid'] = $value['num_iid'];
            $list1[$key]['uid'] = $value['uid'];
            $list1[$key]['weid'] = $value['weid'];
            $list1[$key]['createtime'] = $value['num_iid'];           
		}
      
        
        if(empty($od)){
          die(urldecode(json_encode(array('error'=>1,'goodsdata'=>'','uid'=>$uid,'msg'=>urlencode('云端暂无数据')))));
        }else{
          //$od=urlencode($od['goodsdata']);
          die(urldecode(json_encode(array('error'=>0,'goodsdata'=>$list1,'uid'=>$uid,'msg'=>''))));
        }
    }


	public function doWebMember() {
		//这个操作被定义用来呈现 规则列表
	}

    public function doMobileZc() {//登录
        global $_W, $_GPC;
        $fans = mc_oauth_userinfo();
        if (empty($fans['openid'])){
            message('请从微信端注册');
        }

        if (checksubmit('submit')){
                if (empty($_GPC['username'])){
                    message('请输入用户名！');
                }
                $item = pdo_fetch("SELECT * FROM " . tablename($this->modulename."_member") . " WHERE username='{$_GPC['username']}'");
                if(!empty($item)){
                  message('帐号已存在');
                }

                $data = array(
                    'weid' => $_W['weid'], 
                    'openid'=>$fans['openid'],
                    'avatar'=>$fans['avatar'],
                    'nickname'=>$fans['nickname'],
                    'dluid' => '', 
                    'username' => $_GPC['username'], 
                    'passwd' => $_GPC['passwd'], 
                    'sh' =>1,
                    'endtime' =>'', 
                    'createtime' => TIMESTAMP,);

                //echo '<pre>';
                //print_r($data);
                //exit;
               
                if (!empty($id)){
                    if(!empty($_GPC['passwd'])){
                      $data['passwd']=md5($_GPC['passwd']);
                    }
                    pdo_update($this->modulename."_member", $data, array('id' => $id));
                }else{
                    $data['passwd']=md5($_GPC['passwd']);
                    pdo_insert($this->modulename."_member", $data);
                }
                message('申请成功！', $this -> createMobileUrl('zc', array('op' => 'display')), 'success');
            }
         include $this->template ('zc');
   }
    
    
   


    public function doWebFd(){
        global $_W;
        global $_GPC;
        load ()->func ( 'tpl' );
        $operation = !empty($_GPC['op']) ? $_GPC['op'] : 'display';
        $hgoods = pdo_fetch("SELECT * FROM " . tablename($this->modulename."_member") . " WHERE weid = :weid" , array(':weid' => $_W['uniacid']));
        //print_r($hgoods);
        //exit;
        if ($operation == 'post'){
            $id = intval($_GPC['id']);
            if (!empty($id)){
                $item = pdo_fetch("SELECT * FROM " . tablename($this->modulename."_member") . " WHERE id = :id" , array(':id' => $id));
                $dopenid = unserialize($item['dopenid']);
                foreach ($dopenid as $key => $value) {
                    if (empty($value)) continue;
                    $fop[] = array('openid'=>$value);
                }
                if (empty($item)){
                    message('抱歉，不存在或是已经删除！', '', 'error');
                }
            }
            if (checksubmit('submit')){
                if (empty($_GPC['username'])){
                    message('请输入用户名！');
                }

                $data = array(
                    'weid' => $_W['weid'], 
                    'dluid' => $_GPC['dluid'], 
                    'username' => $_GPC['username'], 
                    'passwd' => $_GPC['passwd'], 
                    'sh' => $_GPC['sh'],
                    'endtime' => $_GPC['endtime'], 
                    'createtime' => TIMESTAMP,);

                //echo '<pre>';
                //print_r($data);
                //exit;
               
                if (!empty($id)){
                    if(!empty($_GPC['passwd'])){
                      $data['passwd']=md5($_GPC['passwd']);
                    }
                    pdo_update($this->modulename."_member", $data, array('id' => $id));
                }else{
                    $data['passwd']=md5($_GPC['passwd']);
                    pdo_insert($this->modulename."_member", $data);
                }
                message('更新成功！', $this -> createWebUrl('fd', array('op' => 'display')), 'success');
            }
        }else if ($operation == 'delete'){
            $id = intval($_GPC['id']);
            $row = pdo_fetch("SELECT id FROM " . tablename($this->modulename."_member") . " WHERE id = :id", array(':id' => $id));
            if (empty($row)){
                message('抱歉，' . $id . '不存在或是已经被删除！');
            }
            pdo_delete($this->modulename."_fd", array('id' => $id));
            message('删除成功！', referer(), 'success');
        }else if ($operation == 'display'){
            if (checksubmit()){
                if (!empty($_GPC['displayorder'])){
                    foreach ($_GPC['displayorder'] as $id => $displayorder){
                        pdo_update($this->modulename."_member", array('displayorder' => $displayorder), array('id' => $id));
                    }
                    message('排序更新成功！', referer(), 'success');
                }
            }
            $condition = '';
            $mlist = pdo_fetchall("SELECT * FROM " . tablename($this->modulename."_member") . " WHERE weid = '{$_W['weid']}'  ORDER BY id desc");

//            $mlist=array();
//            foreach($list as $k=>$v){
//              $olist=$this->postorder($v['outer_item_id']);
//              $mlist[$k]['id']=$v['id'];
//              $mlist[$k]['weid']=$v['weid'];
//              $mlist[$k]['type']=$v['type'];
//              $mlist[$k]['shopname']=$v['shopname'];
//              $mlist[$k]['fzname']=$v['fzname'];
//              $mlist[$k]['fztel']=$v['fztel'];
//              $mlist[$k]['outer_item_id']=$v['outer_item_id'];
//              $mlist[$k]['createtime']=$v['createtime'];
//            }
            //echo '<pre>';
            //print_r($mlist);
            //exit;
           
        }
        include $this -> template('fd');
    }

}
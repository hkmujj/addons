<?php
 //http://wx.youqi18.com/app/index.php?i=3&c=entry&do=duibagoods&m=tiger_taoke
		global $_W,$_GPC;  
        include IA_ROOT . "/addons/tiger_taoke/duiba.php";
        $cfg=$this->module['config'];
        if(empty($cfg['AppKey'])){
          exit;
        }
        checkauth();
        load()->model('mc');
        $uid = mc_openid2uid($_W['openid']);
        $credit=mc_credit_fetch($uid);
        //echo '<pre>';
        //print_r($credit);
        //exit;
        $crdeidt=strval(intval($credit['credit1']));
        //var_dump($crdeidt);
        //exit;
        $url=buildCreditAutoLoginRequest($cfg['AppKey'],$cfg['appSecret'],$uid,$crdeidt);
        //echo $url;
        //exit;
        header('location: ' .$url);
?>
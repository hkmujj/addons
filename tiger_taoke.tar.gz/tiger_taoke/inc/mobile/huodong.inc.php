<?php
global $_W, $_GPC;
$dluid=$_GPC['dluid'];//share id
       $cfg = $this->module['config'];
       
        $list = pdo_fetchall("select * from ".tablename($this->modulename."_gfhuodong")." where weid='{$_W['uniacid']}'  order by px desc");
       $dblist = pdo_fetchall("select * from ".tablename($this->modulename."_cdtype")." where weid='{$_W['uniacid']}' and fftype=1  order by px desc");//底部菜单


       include $this->template ( 'tbgoods/huodong' );
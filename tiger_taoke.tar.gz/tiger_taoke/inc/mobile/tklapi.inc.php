<?php
  global $_W, $_GPC;
       $url=urldecode($_GPC['url']);//链接
       $img=urldecode($_GPC['img']);//图片地址
       $tjcontent=urldecode($_GPC['tjcontent']);//推荐内容    
      $taokouling=$this->tkl($url,$img,$tjcontent);
      $taokou=$taokouling->model;
      settype($taokou, 'string');
      exit($taokou);
?>
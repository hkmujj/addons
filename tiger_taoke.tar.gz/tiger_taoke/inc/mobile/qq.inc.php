<?php
global $_W, $_GPC;
     $cfg=$this->module['config'];
     //exit($cfg['rjqqq']);
     
     $qq=$cfg['rjqqq'];
     exit($qq);
     ?>
<?php
global $_W, $_GPC;


       if($_GPC['op']=='post'){
           $data=array(
               'weid'=>$_W['uniacid'],
               'tbuid'=>$_GPC['tbuid'],
               'sign'=>$_GPC['sign'],
               'endtime'=>$_GPC['endtime'],
               'createtime' => TIMESTAMP
           );
           $go = pdo_fetch("SELECT id FROM " . tablename($this->modulename."_tksign") . " WHERE  tbuid='{$_GPC['tbuid']}'");
            if(empty($go)){
                  $res=pdo_insert($this->modulename."_tksign",$data);
                  if($res=== false){
                    echo '授权失败';
                  }else{
                    //echo '授权成功:'.$_GPC['sign'];
                    $url=$_W['siteroot']."web/index.php?c=profile&a=module&do=setting&m=tiger_taoke";
                    message('授权成功！',$url, 'success');
                  }
            }else{                          
                  $res=pdo_update($this->modulename."_tksign", $data, array('tbuid' =>$_GPC['tbuid']));
                  if($res=== false){
                    echo '授权失败';
                  }else{
                    $url=$_W['siteroot']."web/index.php?c=profile&a=module&do=setting&m=tiger_taoke";
                    message('授权成功！',$url, 'success');
                  }
            }
       }
?>
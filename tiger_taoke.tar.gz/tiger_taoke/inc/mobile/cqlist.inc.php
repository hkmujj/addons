<?php
global $_W, $_GPC;
       include IA_ROOT . "/addons/tiger_taoke/inc/sdk/tbk/tb.php"; 
       $cfg = $this->module['config'];
       $key=trim($_GPC['key']);
       $dluid=$_GPC['dluid'];
       $lx=$_GPC['lx'];
       $lm=$_GPC['lm'];
       $pid=trim($_GPC['pid']);
       $pic_url=$_GPC['pic_url'];
       $key=str_replace("￼"," ",$key);
       $key=trim($key);
       $weid=$_W['uniacid'];
        if(!empty($cfg['gyspsj'])){
          $weid=$cfg['gyspsj'];
        }
         
       //echo $key;
       //exit;

       if(!empty($key)){
         $arr=getfc($key,$_W);
         foreach($arr as $v){
             if (empty($v)) continue;
            $where.=" and itemtitle like '%{$v}%'";
         }
         $cjgoods = pdo_fetchall("SELECT * FROM " . tablename($this->modulename.'_newtbgoods')." where weid='{$weid}' {$where} order by id desc limit 3");
         //echo "<pre>";
         //print_r($cjgoods);
         //exit;
       }

       $goods=getgoodslist($key,'',$_W,$page,$cfg,$lx);
       
       
       if(!empty($dluid)){
          $share=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and id='{$dluid}'");
        }else{
          $fans=mc_oauth_userinfo();
          $openid=$fans['openid'];
          $zxshare=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and from_user='{$openid}'");
        }
        if($zxshare['dltype']==1){
            if(!empty($zxshare['dlptpid'])){
               $cfg['ptpid']=$zxshare['dlptpid'];
               $cfg['qqpid']=$zxshare['dlqqpid'];
            }
            
        }else{
           if(!empty($zxshare['helpid'])){//查询有没有上级
                 $sjshare=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and dltype=1 and id='{$zxshare['helpid']}'");           
            }
        }
        

        if(!empty($sjshare['dlptpid'])){
            if(!empty($sjshare['dlptpid'])){
              $cfg['ptpid']=$sjshare['dlptpid'];
              $cfg['qqpid']=$sjshare['dlqqpid'];
            }   
        }else{
           if($share['dlptpid']){
               if(!empty($share['dlptpid'])){
                 $cfg['ptpid']=$share['dlptpid'];
                 $cfg['qqpid']=$share['dlqqpid'];
               }       
            }
        }
        if(empty($pid)){
        	$pid=$cfg['ptpid'];
	    }else{
	    	$cfg['ptpid']=$pid;
	    }
  
       foreach($goods as $k=>$v){
             $list[$k]['title']=$v->title;  
             $list[$k]['istmall']=$v->userType;  
             $list[$k]['num_iid']=$v->auctionId;
             $list[$k]['org_price']=$v->zkPrice;
             $list[$k]['price']=$v->zkPrice-$v->couponAmount;
             $list[$k]['coupons_price']=$v->couponAmount;
             $list[$k]['goods_sale']=$v->biz30day;
             $list[$k]['url']=$v->auctionUrl;
             $list[$k]['pic_url']='http:'.$v->pictUrl;
       }
      
       include $this->template ( 'cqlist' );
?>
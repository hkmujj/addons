<?php
global $_W, $_GPC;
       $cfg = $this->module['config'];      
       $dluid=$_GPC['dluid'];//share id
        
      

      include $this->template ( 'tbgoods/newhelp' );
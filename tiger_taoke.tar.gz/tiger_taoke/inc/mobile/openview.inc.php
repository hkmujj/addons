<?php
  global $_W, $_GPC;
       $url=urldecode($_GPC['link']);
  
       $user_agent = $_SERVER['HTTP_USER_AGENT'];
       if (strpos($user_agent, 'MicroMessenger') === false) {
		    // 非微信浏览器禁止浏览
			header("Location:".$url); 
		}
       $cfg = $this->module['config'];
       include $this->template ('openview');
?>
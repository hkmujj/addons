<?php
 global $_W, $_GPC;
       $cfg = $this->module['config'];
       $dluid=$_GPC['dluid'];//share id
       $id=$_GPC['id'];
       $pc=$_GPC['pc'];
       $pid=$_GPC['pid'];
       $lm=$_GPC['lm'];//1 联盟  2 云商品库  
       $itemid=$_GPC['itemid'];//云商品库商品ID
       $dlyj=$_GPC['dlyj'];
       $tksign = pdo_fetch("SELECT * FROM " . tablename($this->modulename."_tksign") . " WHERE  tbuid='{$cfg['tbuid']}'");
       
//     $fans=mc_oauth_userinfo();
//     print_r($fans);
//     exit;
       $weid=$_W['uniacid'];

       if(pdo_tableexists('tiger_wxdaili_set')){
          $bl=pdo_fetch("select * from ".tablename('tiger_wxdaili_set')." where weid='{$_W['uniacid']}'");
       }
       //print_r($bl);

        if(!empty($dluid)){
          $share=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and id='{$dluid}'");
        }else{
          $fans=mc_oauth_userinfo();
          
          $openid=$fans['openid'];
          $zxshare=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and from_user='{$openid}'");
        }
        if($zxshare['dltype']==1){
            if(!empty($zxshare['dlptpid'])){
               $cfg['ptpid']=$zxshare['dlptpid'];
               $cfg['qqpid']=$zxshare['dlqqpid'];
            }
            
        }else{
           if(!empty($zxshare['helpid'])){//查询有没有上级
                 $sjshare=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and dltype=1 and id='{$zxshare['helpid']}'");           
            }
        }
        

        if(!empty($sjshare['dlptpid'])){
            if(!empty($sjshare['dlptpid'])){
              $cfg['ptpid']=$sjshare['dlptpid'];
              $cfg['qqpid']=$sjshare['dlqqpid'];
            }   
            $dlewm="http://pan.baidu.com/share/qrcode?w=150&h=150&url=".$sjshare['url'];
        }else{
           if($share['dlptpid']){
               if(!empty($share['dlptpid'])){
                 $cfg['ptpid']=$share['dlptpid'];
                 $cfg['qqpid']=$share['dlqqpid'];
               }       
               $dlewm="http://pan.baidu.com/share/qrcode?w=150&h=150&url=".$share['url'];
            }
        }
        if(empty($pid)){
        	$pid=$cfg['ptpid'];
	    }else{
	    	$cfg['ptpid']=$pid;
	    }

         include IA_ROOT . "/addons/tiger_taoke/inc/sdk/tbk/tb.php"; 
         include IA_ROOT . "/addons/tiger_taoke/inc/sdk/tbk/goodsapi.php"; 
         

          if($lm==1){//联盟产品
             $views['itemid']=$_GPC['num_iid'];
             $views['itemprice']=$_GPC['org_price'];
             $views['itemendprice']=$_GPC['price'];
             $views['couponmoney']=$_GPC['coupons_price'];
             $views['itemsale']=$_GPC['goods_sale'];             
             $views['itemtitle']=$_GPC['title'];
             $views['itempic']=$_GPC['pic_url'];
             $couponendtime=strtotime($_GPC['coupons_end']);
             $ctime=date('Y/m/d H:i:s',$couponendtime);
             $pid=$_GPC['pid'];
             if(!empty($pid) and $pid!=='undefined'){
               $cfg['ptpid']=$pid;
               $views['pid']=$pid;
               $pidSplit=explode('_',$cfg['ptpid']);
               $cfg['siteid']=$pidSplit[2];
               $cfg['adzoneid']=$pidSplit[3];
             }
             //echo $cfg['ptpid'];
             //exit;
             //echo '<pre>';
             //echo $cfg['ptpid'];
             //print_r($cfg);
             //exit;
             $viewslist=getviewcat($views['fqcat'],6,$cfg);


             $ck = pdo_fetch("SELECT * FROM ".tablename('tiger_taoke_ck')." WHERE weid = :weid", array(':weid' => $_W['uniacid']));
             $myck=$ck['data'];
             $turl="https://item.taobao.com/item.htm?id=".$views['itemid'];
             $res=hqyongjin($turl,$ck,$cfg,$this->modulename,'','',$tksign['sign'],$tksign['tbuid'],$_W,1,$views['itemid']);
             $views['tkrates']=$res['commissionRate'];
             

             $views['tk_rate']=$res['commissionRate'];
               if($cfg['yktype']==1){
                   $_GPC['url']=$res['dclickUrl'];
                   $views['url']=$res['dclickUrl'];
                   $rhyurl=$res['dclickUrl'];
               }else{
                  if($res['qq']==1){
                     $rhyurl=$this->rhydx($views['quan_id'],$views['num_iid'],$cfg['ptpid']);
                   }else{
                     $rhyurl=$this->rhy($views['quan_id'],$views['num_iid'],$cfg['ptpid']);//二合一连接
                   }
                   $_GPC['url']=$rhyurl;
                   $views['url']=$rhyurl;
               } 
          }elseif($lm==2){//云商品库产品
          	  
          	  $views=getview($itemid);
          	  if(!empty($itemid)){
          	  	$turl="https://item.taobao.com/item.htm?id=".$_GPC['$itemid'];
                $res=hqyongjin($turl,$ck,$cfg,$this->modulename,'','',$tksign['sign'],$tksign['tbuid'],$_W,1,$itemid); 
          	  }
          	  $viewslist=getviewcat($views['fqcat'],6,$cfg);
          	  $rhyurl=$res['dclickUrl']."&activityId=".$views['quan_id'];
          	  $ctime=date('Y/m/d H:i:s',$views['couponendtime']);
          	  
          	  //echo $ctime;
          	  //exit;
//        	    echo '<pre>';
//        	    print_r($views);
//	      	  	print_r($res);
//	      	  	exit;
          }else{
              if(!empty($cfg['gyspsj'])){
                $weid=$cfg['gyspsj'];
              }
              //echo 'aaaa';
               if(!empty($itemid)){
                  $views=pdo_fetch("select * from".tablename($this->modulename."_newtbgoods")." where weid='{$weid}' and itemid='{$itemid}'");
                  $ctime=date('Y/m/d H:i:s',$views['couponendtime']);
                  $viewslist = pdo_fetchall("select * from ".tablename($this->modulename."_newtbgoods")." where weid='{$weid}' and fqcat='{$views['fqcat']}' order by id desc limit 6");
                  
                  $ck = pdo_fetch("SELECT * FROM ".tablename('tiger_taoke_ck')." WHERE weid = :weid", array(':weid' => $_W['uniacid']));
                   $myck=$ck['data'];
                   $turl="https://item.taobao.com/item.htm?id=".$views['itemid'];
                   $res=hqyongjin($turl,$ck,$cfg,$this->modulename,'','',$tksign['sign'],$tksign['tbuid'],$_W,1,$itemid);
                   
                   if($cfg['yktype']==1){
                       $rhyurl=$res['dclickUrl']."&activityId=".$views['quan_id'];
                   }else{
                      $rhyurl=$this->rhy($views['quan_id'],$itemid,$cfg['ptpid']);//二合一连接
                   }
                }
          }
         

            //PC网站-----------------------------------
            if($pc==1){
              header("location:".$rhyurl);
            }
            //PC结束

            //echo $lxtype;
            //exit;
            
	      if(!empty($rhyurl)){
	      	$tjcontent=$views['itemtitle'];
	      	$rhyurl=str_replace("http:","https:",$rhyurl);
	        $taokouling=$this->tkl($rhyurl,$views['itempic'],$tjcontent);
	        //$taokou=$taokouling->model;
	       // settype($taokou, 'string');
	        $views['taokouling']=$taokouling;
	      }

	      
//	      $bbb=$this->tkl("https://uland.taobao.com/coupon/edetail?e=ZRu9ucpmG0EGQASttHIRqSxezMgi5gP1%2BRUk6VVcjnHOYE6ZUVle2SAJlpJvh4j8EmfKcQeS99F5yepcRw0uu0hMrwC97%2FSyqpYM1S9PYKNY4Y%2Fgpq45GoD0X04J4a2T&traceId=0bb7501515034652584541047e&activityId=cd89c3d03b724b3ba79eb1e1ea1b34a7",'https://img.alicdn.com/bao/uploaded/i4/TB1RZnjXnAPL1JjSZFLYXFbWVXa_M2.SS2_430x430q90.jpg','ssssssss');
//	    echo $bbb;
//      exit;
	
       

//     $fans=$_W['fans'];
//     if(!empty($fans['openid'])){
//       $scgoods = pdo_fetch("SELECT * FROM " . tablename($this->modulename."_shoucang") . " WHERE weid = '{$weid}' and goodsid='{$views['id']}' and openid='{$fans['openid']}'");
//     }

       //
       $yongjin=$views['itemendprice']*$views['tkrates']/100;//佣金
       if($cfg['fxtype']==1){//积分           
            $flyj=intval($yongjin*$cfg['zgf']/100*$cfg['jfbl']);//自购佣金
            $lx=$cfg["hztype"];
        }else{//余额
            $yongjin=number_format($yongjin, 2, '.', ''); 
            $flyj=$yongjin*$cfg['zgf']/100;//自购佣金
            $flyj=number_format($flyj, 2, '.', ''); 
            $lx=$cfg["yetype"];
            if($cfg['txtype']==3){
                $flyj=$flyj*100;
                $lx='集分宝';            
            }
        }

        //echo '<pre>';
        //print_r($views);
        //exit;


          //上报日志-----------------------
            $arr=array(
               'pid'=>$cfg['ptpid'],
               'account'=>"无",
               'mediumType'=>"微信群",
               'mediumName'=>"老虎优惠券".rand(10,5000),
               'itemId'=>$views['num_iid'],
               'originUrl'=>"https://item.taobao.com/item.htm?id=".$views['itemid'],
               'tbkUrl'=>$rhyurl,
               'itemTitle'=>$views['itemtitle'],
               'itemDescription'=>$views['itemtitle'],
               'tbCommand'=>$views['taokouling'],
               'extraInfo'=>"无",
            );
            include IA_ROOT . "/addons/tiger_taoke/inc/sdk/taoapi.php"; 
            $resp=getapi($arr);
//            echo '<pre>';
//            print_r($arr);
//            print_r($resp);
//            exit;
            //日志结束

       $msg = pdo_fetchall("SELECT * FROM " . tablename($this->modulename."_msg") . " WHERE weid = '{$_W['uniacid']}' order by rand() desc limit 50");
       //$url=$_W['siteroot'].str_replace('./','app/',$this->createMobileurl('view',array('id'=>$views['id'],'dluid'=>$dluid,'lm'=>$lm,'num_iid'=>$views['num_iid'],'org_price'=>$views['org_price'],'price'=>$views['price'],'coupons_price'=>$views['coupons_price'],'goods_sale'=>$views['goods_sale'],'url'=>$rhyurl,'title'=>$views['title'],'pic_url'=>$views['pic_url'],'pid'=>$_GPC['pid'])));

       //http://cs.youqi18.com/app/index.php?i=3&c=entry&do=view&m=tiger_taoke&id=undefined&dluid=0&lm=1&num_iid=544317483003&org_price=39.40&price=34.4&coupons_price=5&goods_sale=323&url=&title=&pic_url=http%3A%2F%2Fimg2.tbcdn.cn%2Ftfscom%2Fi3%2FTB1wz4sQpXXXXbaXFXXXXXXXXXX_!!0-item_pic.jpg&pid=mm_13157221_19846366_71352774
       //$url1=$this->dwzewm($url);

       //$emw="http://pan.baidu.com/share/qrcode?w=150&h=150&url=".$url1;
       //$emw=$_W['siteroot'].str_replace('./','app/',$this->createMobileurl('ewmin',array('url'=>$url)));
       //echo '<pre>';
       //print_r($res);
      // exit;
      
      $sjlx=$this->get_device_type();//手机类型 换行 安桌:\r\n  ios:<br>
      if($cfg['xqdwzxs']==1){
      	$urla=$_W['siteroot'].str_replace('./','app/',$this->createMobileurl('openview'))."&link=".$rhyurl;
        $ddwz=$this->dwzw($urla);
      }
      	    
      if($sjlx=='android'){
        	$msg=str_replace('#换行#','', $cfg['tklmb']);
      		$msg=str_replace('#名称#',"{$views['itemtitle']}", $msg);
      	 	$msg=str_replace('#推荐理由#',"{$views['itemdesc']}", $msg);
      	 	$msg=str_replace('#原价#',"{$views['itemprice']}", $msg);
      	 	$msg=str_replace('#券后价#',"{$views['itemendprice']}", $msg);
      	 	$msg=str_replace('#优惠券#',"{$views['couponmoney']}", $msg);
      	 	$msg=str_replace('#淘口令#',"{$views['taokouling']}", $msg);
      	 	$msg=str_replace('#二合一链接#',"{$rhyurl}", $msg);
      	 	$msg=str_replace('#短链接#',"{$ddwz}", $msg);
      }else{
        	$msg=str_replace('#换行#','<br>', $cfg['tklmb']);
      		$msg=str_replace('#名称#',"{$views['itemtitle']}", $msg);
      	 	$msg=str_replace('#推荐理由#',"{$views['itemdesc']}", $msg);
      	 	$msg=str_replace('#原价#',"{$views['itemprice']}", $msg);
      	 	$msg=str_replace('#券后价#',"{$views['itemendprice']}", $msg);
      	 	$msg=str_replace('#优惠券#',"{$views['couponmoney']}", $msg);
      	 	$msg=str_replace('#淘口令#',"{$views['taokouling']}", $msg);
      	 	$msg=str_replace('#二合一链接#',"{$rhyurl}", $msg);
      	 	$msg=str_replace('#短链接#',"{$ddwz}", $msg);
      }
      $rhyurl=urlencode($rhyurl);
       

        include $this->template ( 'tbgoods/style99/view' );
?>
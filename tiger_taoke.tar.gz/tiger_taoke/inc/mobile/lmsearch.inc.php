<?php
global $_W, $_GPC;
       $pid=$_GPC['pid'];
       $dluid=$_GPC['dluid'];
       $cfg=$this->module['config']; 
       $weid=$_W['uniacid'];
        if(!empty($cfg['gyspsj'])){
          $weid=$cfg['gyspsj'];
        }
        
        if(!empty($dluid)){
          $share=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and id='{$dluid}'");
        }else{
          $fans=mc_oauth_userinfo();
          
          $openid=$fans['openid'];
          $zxshare=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and from_user='{$openid}'");
        }
        if($zxshare['dltype']==1){
            if(!empty($zxshare['dlptpid'])){
               $cfg['ptpid']=$zxshare['dlptpid'];
               $cfg['qqpid']=$zxshare['dlqqpid'];
            }
            
        }else{
           if(!empty($zxshare['helpid'])){//查询有没有上级
                 $sjshare=pdo_fetch("select * from ".tablename('tiger_taoke_share')." where weid='{$_W['uniacid']}' and dltype=1 and id='{$zxshare['helpid']}'");           
            }
        }
        

        if(!empty($sjshare['dlptpid'])){
            if(!empty($sjshare['dlptpid'])){
              $cfg['ptpid']=$sjshare['dlptpid'];
              $cfg['qqpid']=$sjshare['dlqqpid'];
            }   
            $dlewm="http://pan.baidu.com/share/qrcode?w=150&h=150&url=".$sjshare['url'];
        }else{
           if($share['dlptpid']){
               if(!empty($share['dlptpid'])){
                 $cfg['ptpid']=$share['dlptpid'];
                 $cfg['qqpid']=$share['dlqqpid'];
               }       
               $dlewm="http://pan.baidu.com/share/qrcode?w=150&h=150&url=".$share['url'];
            }
        }
        if(empty($pid)){
        	$pid=$cfg['ptpid'];
	    }else{
	    	$cfg['ptpid']=$pid;
	    }

      
       

       $ad = pdo_fetchall("SELECT * FROM " . tablename($this->modulename.'_ad') . " WHERE weid = '{$_W['weid']}' order by id desc");
       //$goods = pdo_fetchall("SELECT * FROM " . tablename($this->modulename.'_tbgoods')." where weid='{$weid}' and  qf=1 limit 11");
       //$goodstj = pdo_fetchall("SELECT * FROM " . tablename($this->modulename.'_tbgoods')." where weid='{$weid}' order by id desc limit 11");
       include IA_ROOT . "/addons/tiger_taoke/inc/sdk/tbk/goodsapi.php"; 
       $goods=gettjlist(1,11,'','',$cfg);
       $goodstj=gettjlist(2,11,'','',$cfg);

       include $this->template ( 'lmsearch' );    
?>
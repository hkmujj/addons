<?php
 global $_W, $_GPC;
        $cfg = $this->module['config'];
        $tksign = pdo_fetch("SELECT * FROM " . tablename($this->modulename."_tksign") . " WHERE  tbuid='{$cfg['tbuid']}'");
        include IA_ROOT . "/addons/tiger_taoke/inc/sdk/tbk/tb.php"; 
        $num_iid=$_GPC['key'];
        if(empty($num_iid)){
           $msg='请输入商品ID';
        }
        if($_GPC['op']=='seach'){
           $ck = pdo_fetch("SELECT * FROM ".tablename('tiger_taoke_ck')." WHERE weid = :weid", array(':weid' => $_W['uniacid']));
           $myck=$ck['data'];
           $turl="https://item.taobao.com/item.htm?id=".$num_iid;
           $res=hqyongjin($turl,$ck,$cfg,$this->modulename,'','',$tksign['sign'],$tksign['tbuid'],$_W); 
           //echo '<pre>';
           //print_r($res);
        }                 
       
       
       include $this->template ( 'yjjc' );  
?>
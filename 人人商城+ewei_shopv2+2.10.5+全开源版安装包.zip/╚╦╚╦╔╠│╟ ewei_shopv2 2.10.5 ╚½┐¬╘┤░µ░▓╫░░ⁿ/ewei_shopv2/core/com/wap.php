<?php
if (!(defined('IN_IA'))) {
	exit('Access Denied');
}

class Wap_EweiShopV2ComModel extends ComModel
{
	public function getSet()
	{
		return '';
	}
}


?>